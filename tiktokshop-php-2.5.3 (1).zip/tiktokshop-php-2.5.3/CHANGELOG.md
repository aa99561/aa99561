# Change Log

## v1.1.0

### Changes

* Added webhook receiver integration

## v1.0.0 (Sep 20, 2022)

### Stable release

* Support all Tiktok Shop API
